Remarque: 
On n'a pas pu lire les fichiers lorsque le fichier .py n'est pas dans le dossier Labyrinthe pour des raisons qu'on ignore.
Il est possible d'exucuter le programme lorsque le fichier .py est dans le dossier Labyrinthe. 

Merci!